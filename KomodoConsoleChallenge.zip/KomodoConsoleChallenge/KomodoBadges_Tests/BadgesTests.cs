﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace KomodoBadges_Tests
{
    [TestClass]
    public class BadgesTests
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
