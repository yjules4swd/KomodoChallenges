﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KomodoBadges_Repository
{
    public class BadgesRepository
    {
        public Dictionary<int, List<string>> Badges = new Dictionary<int, List<string>>();
        
    }
}
